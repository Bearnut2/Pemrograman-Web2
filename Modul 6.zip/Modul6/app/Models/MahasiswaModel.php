<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $nama = "M. Aqiila Yufanda";
    protected $nim = "2110817310010";
    protected $prodi = "Teknologi Informasi";
    protected $motto = "Work Hard Play Hard";
    protected $hobi = "Main Game dan Basket";
    protected $skill = "Fast Leaner";
    protected $foto = "foto.png";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getmotto()
    {
        return $this->motto;
    }
    public function gethobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getFoto()
    {
        return $this->foto;
    }
}