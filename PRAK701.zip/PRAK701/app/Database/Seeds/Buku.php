<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use App\Models\BukuModel;

class Buku extends Seeder
{
    public function run()
    {
        $this->db->table('buku')->insert([
            'judul' => 'Harry Potter and the Chamber of Secrets ',
            'penulis' => 'J.K. Rowling',
            'penerbit' => 'Bloomsbury Publishing',
            'tahun_terbit' => '1998'
        ]);

        $this->db->table('buku')->insert([
            'judul' => 'Harry Potter and the Order of the Phoenix ',
            'penulis' => 'J.K. Rowling',
            'penerbit' => 'Bloomsbury Publishing',
            'tahun_terbit' => '2003'
        ]);

        $this->db->table('buku')->insert([
            'judul' => 'Harry Potter and the Half-Blood Prince  ',
            'penulis' => 'J.K. Rowling',
            'penerbit' => 'Bloomsbury Publishing',
            'tahun_terbit' => '2005'
        ]);
    }
}
